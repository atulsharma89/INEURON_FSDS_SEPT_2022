TRAINING_BUCKET_NAME = "scania-sensor-pipeline"
PREDICTION_BUCKET_NAME = "sensor-datasource"